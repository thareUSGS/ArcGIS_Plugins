README for USGS Astrogeology Science Center Well Known Text (WKT) Esri Add-in

06/29/2017

Select a single feature and return the WKT text string of the object to the Python 
console.  This toolbar is used by USGS staff to update IAU feature nomenclature for 
supported web services.

The "WKT" button returns a WKT string of coordinates defining the object.

The "WKT 360" button modifies longitude coordinates to match 0-360 coordinate systems,
such as on Mars.  Values are truncated to floating point numbers.

To use, download the file NomenclatureWKT.esriaddin and double-click to install.  The 
toolbar will be available for use the next time ArcMap is opened.  

For public use, created by the USGS Astrogeology Science Center.

For support contact:
Marc Hunter
mahunter@usgs.gov
USGS Astrogeology
2255 N. Gemini Dr.
Flagstaff, AZ 86001
